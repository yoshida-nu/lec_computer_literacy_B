console.log('Hello World!');
console.log(10 + 5);