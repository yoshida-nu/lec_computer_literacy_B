let username = '田中';
let age = 19;
console.log(username);
console.log(age);

username = '鈴木';
age = 23;
console.log('名前：' + username);
console.log('年齢：' + age);