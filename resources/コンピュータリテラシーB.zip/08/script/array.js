// 配列を定義する
let fruits = ['Apple', 'Banana'];

// 配列の長さを取得してコンソールに表示する
console.log(fruits.length); // 2

// 配列の内容をコンソールに表示する
console.log(fruits); // ['Apple', 'Banana']

// 配列内の要素をインデックス指定してコンソールに表示する
console.log(fruits[0]); // Apple
console.log(fruits[1]); // Banana

// 配列の末尾に要素を追加してコンソールに表示する
fruits.push('Orange');
console.log(fruits); // ['Apple', 'Banana', 'Orange']

// 配列の先頭に要素を追加してコンソールに表示する
fruits.unshift('Strawberry');
console.log(fruits); // ['Strawberry', 'Apple', 'Banana', 'Orange']

// 配列の末尾から要素を削除してコンソールに表示する
fruits.pop();
console.log(fruits); // ['Strawberry', 'Apple', 'Banana']

// 配列の先頭から要素を削除してコンソールに表示する
fruits.shift();
console.log(fruits); // ['Apple', 'Banana']
