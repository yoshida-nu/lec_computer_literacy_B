// 引数も戻り値もない関数
// 「本日は晴天なり」と表示する関数を定義
function hello() {
    console.log('本日は晴天なり');
}

// 定義した関数を呼び出す
hello();

// 引数だけある関数
// 引数を表示する関数を定義
function print_data(data) {
    console.log(data);
}

// 定義した関数を呼び出す
print_data('Hello World!'); // Hello World!を表示
print_data(1 + 2); // 3を表示

// 引数も戻り値もある関数
// 2つの数を足す関数を定義
function add(x, y) {
    return x + y;
}

// 定義した関数を呼び出す
console.log(add(10, 20)); // 30を表示
console.log(add(-10, 20)); // 10を表示
