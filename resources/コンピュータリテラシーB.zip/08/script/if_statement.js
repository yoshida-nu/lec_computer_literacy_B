// 変数の宣言と初期化
let age = 19;

// 基本的なif文の例
if (age > 18) {
    // 条件式がtrueの場合に実行
    console.log('成人です。');
}

// 変数の宣言と初期化
let temperature = 32;

// if-else文の例
if (temperature > 30) {
    // 条件がtrueの場合に実行
    console.log('It is hot outside!');
} else {
    // 条件がfalseの場合に実行
    console.log('It is not so hot outside.');
}

// 変数の宣言と初期化
let score = 75;

// if-else if-else文の例
if (score >= 70) {
    // scoreが70以上場合に実行
    console.log('Good job!');
} else if (score >= 50) {
    // scoreが50以上70未満の場合に実行
    console.log('Passed.');
} else {
    // 上記の条件にどれも当てはまらない場合に実行
    console.log('Failed.');
}

// 変数の宣言と初期化
let yourAge = 25;
let petType = 'cat'; // 犬派:dog or 猫派:cat

if (yourAge >= 18) {
    if (petType == 'dog') {
        console.log('成年の犬派');
    } else {
        console.log('成年の猫派');
    }
} else {
    if (petType == 'dog') {
        console.log('未成年の犬派');
    } else {
        console.log('未成年の猫派');
    }
}

// 上のif文と同じ結果となるコード
if (yourAge >= 18 && petType == 'dog') {
    console.log('成年の犬派');
} else if (yourAge >= 18 && petType == 'cat') {
    console.log('成年の猫派');
} else if (yourAge < 18 && petType == 'cat') {
    console.log('未成年の犬派');
} else {
    console.log('未成年の猫派');
}
