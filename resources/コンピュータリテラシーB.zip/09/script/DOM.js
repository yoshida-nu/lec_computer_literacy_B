// 要素を取得
let elem1 = document.querySelector('p');

// 要素のid属性と内容をコンソールに表示
console.log(elem1.getAttribute('id'));
console.log(elem1.textContent);

// 要素の内容を変更
elem1.textContent = 'これは変更されたテキストです（1つ目）。';

// 要素を取得
let elem2 = document.getElementById('p2');

// 要素のid属性と内容をコンソールに表示
console.log(elem2.getAttribute('id'));
console.log(elem2.textContent);

// 要素の内容を変更
elem2.textContent = 'これは変更されたテキストです（2つ目）。';
