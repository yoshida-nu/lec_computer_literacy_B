// ボタン要素を取得
let button = document.getElementById('myButton');

// ボタンにイベントリスナーを登録
button.addEventListener('click', function (e) {
    let message = document.getElementById('message');
    message.textContent = 'メッセージが変更されました！';
    console.log(e.clientX); // クリックした位置（X座標）
    console.log(e.clientY); // クリックした位置（Y座標）
});
