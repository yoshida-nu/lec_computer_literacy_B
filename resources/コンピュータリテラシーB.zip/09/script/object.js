// オブジェクトの定義
let mont_blanc = {
    material: '栗',
    price: 300,
    season: '秋',

    introduce: function () {
        console.log('当店自慢のモンブランです！');
    },

    show_price: function (quantity) {
        console.log(quantity * this.price)
    }
};

// オブジェクトのプロパティにアクセスする
console.log(mont_blanc.material);
console.log(mont_blanc.price);
console.log(mont_blanc.season);

// オブジェクトのメソッドを実行する
mont_blanc.introduce();
mont_blanc.show_price(2);

// オブジェクトのプロパティを変更する
mont_blanc.price = 200;
console.log(mont_blanc.price);
