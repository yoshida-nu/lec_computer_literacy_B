let height = 173;
let weight = 65;

