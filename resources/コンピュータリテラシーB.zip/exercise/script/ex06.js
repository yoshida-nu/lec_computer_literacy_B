function () {
    if () {
        console.log(a);
    } else {
        console.log(b);
    }
}

show_max(7, 3);
show_max(10, 17);
show_max(-5, -3);
