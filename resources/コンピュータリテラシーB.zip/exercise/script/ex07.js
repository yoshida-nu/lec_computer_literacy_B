// 要素を取得
let button;

// 要素にイベントリスナーを登録
button.addEventListener(function (e) {
    let elem;
    elem.textContent = '課題完了！';
});
