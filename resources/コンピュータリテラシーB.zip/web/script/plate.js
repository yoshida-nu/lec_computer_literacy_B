$(function(){
    let cvs = $('#cakeplate');
    cvs[0].width = 460;
    
    
    let ctx;
    ctx.fillStyle = "maroon";
    ctx.fillRect(0, 0, 460, 200);
    ctx.fillStyle = "lemonchiffon";
    
    
    let flag_plate_white = true;

    cvs.click(function(e){
        let x_posi;
        let y_posi;
        if ((x_posi >= 0 && x_posi <= 10) ||
            (x_posi >= 450 && x_posi <= 460) ||
            (y_posi >= 0 && y_posi <= 10) ||
            (y_posi >= 190 && y_posi <= 200)){
            if (flag_plate_white){
                ctx.fillStyle = "lemonchiffon";
                ctx.fillRect(0, 0, 460, 200);
                ctx.fillStyle = "maroon";
                ctx.fillRect(10, 10, 440, 180);
                flag_plate_white = false;
            } else{
                ctx.fillStyle = "maroon";
                ctx.fillRect(0, 0, 460, 200);
                ctx.fillStyle = "lemonchiffon";
                ctx.fillRect(10, 10, 440, 180);
                flag_plate_white = true;
            }
        }
    });

    let startX;
    let startY;
    let mousedown;

    function draw(x,y){
        if (flag_plate_white){
            ctx.strokeStyle = "maroon";
        }else{
            ctx.strokeStyle = "lemonchiffon";
        }
        ctx.lineWidth = 5;
        ctx.beginPath();
        ctx.moveTo(startX, startY);
        ctx.lineTo(x,y);
        ctx.closePath();
        ctx.stroke();
        startX = x;
        startY = y;
    }

    cvs.mousedown(function(e){
        startX;
        startY;
        mousedown;
    });
    
    cvs.mousemove(function(e){
        if (mousedown){
            x;
            y;
            
        }
    });

    $(window).mouseup(function(){
        mousedown;
    });
});
